COPY lineitem FROM 'tpch_sf01/lineitem.csv' (FORMAT 'csv', quote '"', delimiter ',', header 0);
COPY orders FROM 'tpch_sf01/orders.csv' (FORMAT 'csv', quote '"', delimiter ',', header 0);
COPY partsupp FROM 'tpch_sf01/partsupp.csv' (FORMAT 'csv', quote '"', delimiter ',', header 0);
COPY part FROM 'tpch_sf01/part.csv' (FORMAT 'csv', quote '"', delimiter ',', header 0);
COPY customer FROM 'tpch_sf01/customer.csv' (FORMAT 'csv', quote '"', delimiter ',', header 0);
COPY supplier FROM 'tpch_sf01/supplier.csv' (FORMAT 'csv', quote '"', delimiter ',', header 0);
COPY nation FROM 'tpch_sf01/nation.csv' (FORMAT 'csv', quote '"', delimiter ',', header 0);
COPY region FROM 'tpch_sf01/region.csv' (FORMAT 'csv', quote '"', delimiter ',', header 0);
